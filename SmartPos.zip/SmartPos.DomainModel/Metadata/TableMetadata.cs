﻿using SmartPos.DomainModel.Base;

namespace SmartPos.DomainModel.Metadata
{
    public class TableMetadata : IMetadata
    {
    }
}
