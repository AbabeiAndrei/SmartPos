﻿namespace SmartPos.Desktop.Data
{
    public static class PosClient
    {
        public static string LocationName { get; set; }
        //to do - just for test
            = "Filicori Zecchini Bar";
    }
}
