﻿namespace SmartPos.Ui.Theming
{
    public interface IThemeable
    {
        void ApplyTheme(ITheme theme);
    }
}
