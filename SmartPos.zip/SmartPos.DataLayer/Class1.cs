﻿using System;

namespace SmartPos.DataLayer
{
    public class Class1
    {
    }
}
