﻿namespace SmartPos.DomainModel.Base
{
    public interface ISoftDeletable
    {
        bool Deleted { get; set; }
    }
}
