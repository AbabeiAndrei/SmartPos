﻿namespace SmartPos.DomainModel.Base
{
    public interface IMetadata
    {
    }
}
