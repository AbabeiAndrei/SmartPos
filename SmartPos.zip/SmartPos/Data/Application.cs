﻿using System;
using SmartPos.Desktop.Communication;

// ReSharper disable once CheckNamespace (Partial class)
namespace SmartPos.Desktop
{
    public static partial class Application
    {
        private static ApiClient _apiClient;
        private static IFormatProvider _uiFormatProvider;
    }
}
