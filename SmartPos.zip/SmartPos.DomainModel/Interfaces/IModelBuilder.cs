﻿namespace SmartPos.DomainModel.Interfaces
{
    public interface IModelBuilder
    {
        void Build();
    }
}
