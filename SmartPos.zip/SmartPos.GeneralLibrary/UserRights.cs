﻿namespace SmartPos.GeneralLibrary
{
    public static class UserIdentity
    {
        public const string AUTHORISATION_HEADER = "Authorization";
    }

    public static class UserRights
    {
        public const string ORDER = "SmartPos.Order";
    }
}
